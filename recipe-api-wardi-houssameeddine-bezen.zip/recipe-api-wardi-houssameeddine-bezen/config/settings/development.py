from .base import *


DEBUG = True
ALLOWED_HOSTS = ['localhost']

MEDIA_URL = '/media/'
MEDIA_ROOT = os.path.join(BASE_DIR, 'media')
