# Recipe App React Front-Interface

## Technologies Used

- React.js
- Redux
- TailwindCSS
- Backend using Django, DRF

## Basic Features

1. JWT based user registration and login.
2. Create/Update/Delete your recipe.

## Quick Start

1. Clone this repository to your local machine.
2. Add the necessary packages => `yarn add`
3. Run `yarn start` to see the project live.

## License

Usage is provided under the [MIT License](http://opensource.org/licenses/mit-license.php). See LICENSE for the full details.
